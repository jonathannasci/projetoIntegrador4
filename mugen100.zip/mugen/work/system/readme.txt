M.U.G.E.N System sprites
------------------------

M.U.G.E.N       (c) 2001 Elecbyte
                www.elecbyte.com


This version updated: 1 April 2001

The sprites in this directory are used to build system.sff
in the data/ directory. You can use them as a starting base
for your own motif.

Unzip these files in work/system under your MUGEN directory.
You will need SprMaker, available from our web page.

From your MUGEN directory, you can type
  sprmaker < work\system\system.txt

To change the behavior of the backgrounds and other settings,
edit the system.def in your motif directory.

You can find some information on backgrounds in 
stages/stage0.def or stages/kfm.def.
