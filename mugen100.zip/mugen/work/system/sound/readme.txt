M.U.G.E.N System sound effects
------------------------------

M.U.G.E.N       2001 Elecbyte
                www.elecbyte.com


This version updated: 5 July 2000

This directory contains the sprites required to build
data/system.snd, the sound file for system sound effects.

Unzip these files in work/system/sound under your MUGEN directory.
You will need SndMaker, available from our web page.

From your MUGEN directory, you can type
  sndmaker < work\system\sound\sound.txt

Edit system.def in your motif directory to set up sound effects.
