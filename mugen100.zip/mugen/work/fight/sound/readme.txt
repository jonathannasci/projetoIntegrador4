M.U.G.E.N In-game sound effects
-------------------------------

M.U.G.E.N       2001 Elecbyte
                www.elecbyte.com


This version updated: 5 July 2000

This directory contains the sprites required to build
data/fight.snd, the sound file for in-game sound effects.

Unzip these files in work/fight/sound under your MUGEN directory.
You will need SndMaker, available from our web page.

From your MUGEN directory, you can type
  sndmaker < work\fight\sound\sound.txt

Edit data/fight.def to set up sound effects.
